import React,{Component} from "react"
class Buy extends Component{

    constructor(props){
        super(props)
        this.state = {
            showSuccessLabel: false
        }
        this.successStyle = {
            'color': 'green'
        }
        this.errorStyle = {
            'color': 'red'
        }
    }

    buyProduct = () => {
        this.setState({
            showSuccessLabel: true
        })
        return this.props.handler()
    }

    render() {
        return(
            <div>
                <div>
                    <label hidden={this.props.qtyAvailable > 0} style={this.errorStyle}> Lo sentimos! No hay mas stock</label>
                </div>
                <button disabled={this.props.qtyAvailable < 1} onClick={this.buyProduct}>Buy this product! </button>
                <div>
                    <label hidden={!this.state.showSuccessLabel} style={this.successStyle}> Gracias por su compra! </label>
                </div>
            </div>
        )
    }
}

export default Buy
