function Login() {

    return (
        <form>
            <h2>Login</h2>
            <label>Username</label>
            <input type="username"></input>
            <label>Password</label>
            <input type="password"></input>
            <button>Log In</button>

            <h2>Register</h2>
            <label>Name</label>
            <input type="text"></input>
            <label>Username</label>
            <input type="username"></input>
            <label>Password</label>
            <input type="password"></input>
            <button>Register</button>

        </form>
    )
}

export default Login;
